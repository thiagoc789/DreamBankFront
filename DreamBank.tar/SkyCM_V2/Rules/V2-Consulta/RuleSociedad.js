/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */
export default function RuleSociedad(context) {
    //var pernr = context.evaluateTargetPath("#Application/#ClientData/#Property:UserId");
    var kunnr = context.evaluateTargetPath("#Page:EstadoCartera/#Control:FC_List_ClientesCartera/#SelectedValue");
	var dialog = context.nativescript.uiDialogsModule;
	var campo = context.evaluateTargetPath("#Page:EstadoCartera/#Control:FC_SOC_CAR");
	// creo una variable global y le digo que se aloje en la pagina de consultas
//	let clientData = context.evaluateTargetPathForAPI('#Page:Consultas').getClientData();
	return context.read('/SkyCM_V2/Services/SkyCM_V2.service', 'CLIENTEINFO', [], `$filter=KUNNR eq '${kunnr}'`).then((results) => {
		
		if (results && results.length > 0) {
			let prod = results.getItem(1);
			// aqui le digo que haga una variable que se llame PERNR
			//clientData.PERNR = prod.PERNR;
			const per= prod.BUKRS                                 ;
			campo.setValue(per)
            //context.executeAction('/SkyCM_V2/Rules/V2-Consulta/RuleSociedad.js');
		return per;
		//	return context.executeAction('/SkyCM_V2/Actions/Service/InitializeOfflineSuccessMessage.action')
		} else {
		return true;
		}
	});
}