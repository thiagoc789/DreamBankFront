/**#Page:Identificarse/#Control:numeroIdentificacion/#Value
 * Describe this function...
 * @param {Icontext} context
 */
export default function tipoAporte(context) {
    var detalleAporte = "";
    var titulo= "";
    var dialog = context.nativescript.uiDialogsModule;
    var optionAporte = context.evaluateTargetPath("#Page:Tipo_Aporte/#Control:ListPickerTipoAporte/#SelectedValue");
    var campoDetalles = context.evaluateTargetPath("#Page:Tipo_Aporte/#Control:notas");
    var notas = context.evaluateTargetPath("#Page:Tipo_Aporte/#Control:notas");
    
    switch(optionAporte){
        case "Beca completa":
        detalleAporte = "Beca completa:\n\n100.000.000 con lo cual tiene un primer beneficio de impuestos de 20.000.000 y segundo beneficio 25.000.000 total aporte 55.000.000"
        notas.setValue(detalleAporte)
        break;
        case "Beca de salvamento":
        detalleAporte = "Beca salvamento:\n\nValor de 20.000.000 con primer beneficio tributario de 12.000.000 Total aporte 8.000.000"
        notas.setValue(detalleAporte)
        break;
        case "Academia Técnica":
        detalleAporte = "Academia técnica:\n\nAcademia para que el mundo tenga más personas capaces de aplicar tecnología 900 USD"
        notas.setValue(detalleAporte)
        break;
        case "Aporte libre":
        detalleAporte = "Aporte libre:\n\nPuedes apoyar a los gastos universitarios de un estudiante con un aporte entre los 5.000.000 a los 20.000.000"
        notas.setValue(detalleAporte)
        break;    
    } 
        
        campoDetalles.setValue(detalleAporte);
        
        
    
}
