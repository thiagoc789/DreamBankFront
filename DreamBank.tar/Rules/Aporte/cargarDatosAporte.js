/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */
export default function cargarDatosAporte(context) {
    var dialog = context.nativescript.uiDialogsModule;
    var listpicker = context.evaluateTargetPath("#Page:Tipo_Aporte/#Control:ListPickerTipoAporte/#SelectedValue");
    var controlId = context.evaluateTargetPath("#Control:tipoAporte");
    controlId.setValue(listpicker)

    var identificacion = context.evaluateTargetPath("#Page:Identificarse/#Control:numeroIdentificacion/#Value");

    var query = "$filter=Identidicacion eq " + identificacion

    //, `$filter=IDENTIDICACION eq '${identificacion}'`
    return context.read('/DreamBank/Services/DreamBankOnline.service', 'Aportador', [], query).then((results) => {

        var controlCorreo = context.evaluateTargetPath("#Control:correoAportador");
        var controlNombre = context.evaluateTargetPath("#Control:nombreAportador");
        var telefono = context.evaluateTargetPath("#Control:telefono");

        controlCorreo.setValue(results.getItem(0).mail)
        telefono.setValue(results.getItem(0).col1)
        controlNombre.setValue(results.getItem(0).nombre + " " + results.getItem(0).apellido)


    });
}
