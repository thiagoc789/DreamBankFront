/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */
export default function cargarDatos(context) {
    var dialog = context.nativescript.uiDialogsModule;
    var identificacion = context.evaluateTargetPath("#Page:Identificarse/#Control:numeroIdentificacion/#Value");

    var query = "$filter=Identidicacion eq " + identificacion

    //, `$filter=IDENTIDICACION eq '${identificacion}'`
    return context.read('/DreamBank/Services/DreamBankOnline.service', 'Aportador', [], query).then((results) => {

        var controlId = context.evaluateTargetPath("#Control:identificacion");
        var controlNombre = context.evaluateTargetPath("#Control:nombre");

        controlId.setValue(results.getItem(0).Identidicacion)
        controlNombre.setValue(results.getItem(0).nombre + " " + results.getItem(0).apellido)


    });
}
