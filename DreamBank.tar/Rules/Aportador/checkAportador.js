/**
 * Describe this function...
 * @param {Icontext} context
 */
export default function checkAportador(context) {

    var dialog = context.nativescript.uiDialogsModule;
    var identificacion = context.evaluateTargetPath("#Page:Identificarse/#Control:numeroIdentificacion/#Value");
    var query = "$filter=Identidicacion eq " + identificacion

    return context.read('/DreamBank/Services/DreamBankOnline.service', 'Aportador', [], query).then((results) => {
        if(results.length > 0 ){
            var formulario = "/DreamBank/Actions/Aportador/Nav_Bienvenida_Aportador.action"
            return context.executeAction(formulario)

        }else {
            var formulario = "/DreamBank/Actions/Aportador/msg_crearUsuario.action"
            return context.executeAction(formulario)
        }
    });
}
