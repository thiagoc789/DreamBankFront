/**
 * Describe this function...
 * @param {IClientAPI} clientAPI
 */
export default function Estudiante_FormatoFoto(context) {
    var dialog = context.nativescript.uiDialogsModule;

    return context.read('/DreamBank/Services/DreamBankOnline.service', 'Estudiante', [], '').then((results) => {
        for(var i = 0; i < tamano; i++){
            var url = results.getItem(i).fotoUrl
            dialog.alert(url)
            
            
            
        }

        return url;
         

    }
    
    );


}
